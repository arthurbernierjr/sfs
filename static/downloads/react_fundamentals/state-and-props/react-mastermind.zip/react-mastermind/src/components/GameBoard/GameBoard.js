import GuessRow from '../GuessRow/GuessRow';

const GameBoard = (props) => (
  <div>
    <GuessRow />
    <GuessRow />
  </div>
);

export default GameBoard;
