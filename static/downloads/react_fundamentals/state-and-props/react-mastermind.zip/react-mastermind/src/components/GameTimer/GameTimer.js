const GameTimer = (props) => (
  <div>
    GameTimer
  </div>
);

export default GameTimer;
