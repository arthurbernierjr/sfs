const NewGameButton = (props) => (
  <button>
    New Game
  </button>
);

export default NewGameButton;
