const ScoreButton = (props) => (
  <button>
    Score Guess
  </button>
);

export default ScoreButton;
