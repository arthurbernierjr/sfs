import './App.css';
import Map from './components/Map/Map';

function App () {
  return (
    <div className='App'>
      <Map />
      <header className='App-header'>REACT WEATHER</header>
    </div>
  );
}

export default App;
